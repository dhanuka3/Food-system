package com.user.Food.Delivery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodDeliveryManagmentSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
